INSERT INTO sec_user (email, encryptedPassword, enabled)
VALUES ('test@01', '$2y$12$icPuBw2KwRU7FmCU.QHEOOdYnM3C/o1YOEsE.xtUsVK13zcC13WHS', 1);

INSERT INTO sec_user (email, encryptedPassword, enabled)
VALUES ('guest.guest@sheridancollege.ca', '$2a$10$Zfqz.X2Mlg3Ob7ZXmjwoGO/xH4hy2Y9PN.31IVXbEdB.DX/mIOZ5G', 1);

INSERT INTO sec_user (email, encryptedPassword, enabled)
VALUES ('john.white@sheridancollege.ca', '$2a$10$uq5P/KkFUDPjPyutE2usd.vphkLnsleZrQs21tT15lp6MJeCzHN/G', 1);


INSERT INTO sec_role (roleName)
VALUES ('ROLE_ADMIN');

INSERT INTO sec_role (roleName)
VALUES ('ROLE_MEMBER');

INSERT INTO sec_role (roleName)
VALUES ('ROLE_GUEST');


INSERT INTO user_role (userId, roleId)
VALUES (1, 1);

INSERT INTO user_role (userId, roleId)
VALUES (2, 2);

INSERT INTO user_role (userId, roleId)
VALUES (3, 3);

