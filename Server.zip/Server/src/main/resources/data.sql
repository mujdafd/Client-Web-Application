INSERT INTO contact (name, phoneNumber, address, email, role)
VALUES ('contact01', '123123123', 'test address', 'test@test.test', 'ROLE_ADMIN');
