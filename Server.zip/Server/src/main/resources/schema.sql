CREATE TABLE contact(
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NULL,
    phoneNumber VARCHAR(100) NULL,
    address VARCHAR(100) NULL,
    email VARCHAR(100) NULL,
    role VARCHAR(100) NULL
);
